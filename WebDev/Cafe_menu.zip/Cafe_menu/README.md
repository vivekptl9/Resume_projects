# Cafe_menu
## A Simple Cafe menu showcasing HTML and CSS skills for portfolio project done as a part of freecode camp training.
